# CM3035 Midterm – WHO Health API (Life Expectancy + Suicide Mortality)

This Django + DRF application loads two small WHO-based CSV datasets into SQLite and exposes several REST endpoints.

## Quick start (Windows PowerShell)

```powershell
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt

python manage.py migrate
python manage.py create_default_admin
python manage.py load_who_data

python manage.py test
python manage.py runserver
```

Open the landing page:
- http://127.0.0.1:8000/

Swagger UI:
- http://127.0.0.1:8000/api/docs/

Admin:
- http://127.0.0.1:8000/admin/
- username: admin
- password: admin1234

## Data loading script

- `health/management/commands/load_who_data.py`
- CSVs live in: `data/`


## AJAX demo

The landing page includes a small AJAX widget that calls the REST API using `fetch()` without reloading the page.
